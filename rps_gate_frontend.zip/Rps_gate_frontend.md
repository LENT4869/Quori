🔐 RPS Gate Frontend Demo (HTML + JS)
This repository includes only the frontend code (HTML + JavaScript) for the rps-gate authentication interface, which is part of the Quori Secure Browser Project.

⚠️ Important Notice
This demo includes:

rps_gate.html: The UI page for passphrase input

script.js: Frontend logic for basic RPS input, salt/hash generation, and IndexedDB storage

This demo does not include:

Backend WebUI controller code

Chromium registration files (e.g., BUILD.gn, .grd)

Internal browser blocking logic (DevTools, extensions, navigation, etc.)

👉 These files are for demonstration only. Do not consider them as a complete or secure implementation.

Made with 🔧 and 💡 by LENT, from Taiwan.