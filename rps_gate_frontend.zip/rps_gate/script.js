const wordList = [
  "apple", "banana", "cat", "dog", "elephant", "fish", "grape", "hat", "ice", "jungle",
  "kite", "lion", "monkey", "nest", "orange", "pig", "queen", "rabbit", "sun", "tiger",
  "umbrella", "van", "whale", "xray", "yellow", "zebra"
];
let correctMnemonic = '';
let verificationIndices = [];
let showLogs = false;


function shouldReset() {
  const params = new URLSearchParams(window.location.search);
  return params.get('reset') === 'true';
}

async function setupPage() {
  const reverify = shouldReset();

  if (reverify) {
    const db = await openDB();
    const tx = db.transaction('settings', 'readwrite');
    const store = tx.objectStore('settings');
    await store.clear();
    await tx.done;

    window.history.replaceState({}, document.title, "chrome://rps-gate/");

    const newMnemonic = generateRandomMnemonic();
    correctMnemonic = newMnemonic;
    return renderRPSPage(newMnemonic);
  }

  const mnemonic = await getSetting('mnemonic');
  const storedHash = await getSetting('mnemonicHash');

  // 如果其中一個不存在 → 要重設
  if (!mnemonic || !storedHash || !isValidHash(storedHash)) {
    const newMnemonic = generateRandomMnemonic();
    correctMnemonic = newMnemonic;
    return renderRPSPage(newMnemonic, true);
  }

  return renderVerificationUI();
}





function isValidHash(hash) {
  return /^[a-f0-9]{64}$/.test(hash);
}

function generateRandomMnemonic() {
  const mnemonic = [];
  for (let i = 0; i < 12; i++) {
    const word = wordList[Math.floor(Math.random() * wordList.length)];
    const prefix = word.slice(0, 3);
    const noise = generateRandomNoise(3);
    mnemonic.push(prefix + noise);
  }
  return mnemonic.join(' ');
}

function generateRandomNoise(length = 3) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}





async function sha256WithSalt(text, salt = 'quori-default') {
  const encoder = new TextEncoder();
  const data = encoder.encode(text + salt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuffer))
              .map(b => b.toString(16).padStart(2, '0')).join('');
}


async function saveSetting(key, value) {
  const db = await openDB();
  const tx = db.transaction('settings', 'readwrite');
  const store = tx.objectStore('settings');
  await store.put({ key, value });
  await tx.done;
}

async function getSetting(key) {
  const db = await openDB();
  const tx = db.transaction('settings', 'readonly');
  const store = tx.objectStore('settings');
  const req = store.get(key);
  return new Promise((resolve, reject) => {
    req.onsuccess = e => resolve(e.target.result ? e.target.result.value : null);
    req.onerror = reject;
  });
}

async function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('RPSdb', 1);
    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('logs')) {
        db.createObjectStore('logs', { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = e => resolve(e.target.result);
    request.onerror = e => {
      console.error('❌ 開啟 RPSdb 錯誤：', e.target.error);
      reject(e.target.error);
    };
    
  });
}

function renderRPSPage(rps, isReset = false) {
  const appDiv = document.getElementById('app');
  clearElement(appDiv);

  const title = document.createElement('h2');
  title.innerText = '🎉 已為您產生 RPS，請妥善紀錄：';

  const rpsBox = document.createElement('div');
  rpsBox.className = 'rps-box';
  rpsBox.innerText = rps;

  const confirmBtn = document.createElement('button');
  confirmBtn.innerText = '我已抄寫完成';
  confirmBtn.addEventListener('click', () => saveRPS(rps));

  appDiv.appendChild(title);
  appDiv.appendChild(rpsBox);
  appDiv.appendChild(confirmBtn);

  // 只有 reset 時才加上提示
  if (!isReset) {
    const tip = document.createElement('p');
    tip.style.marginTop = '16px';
    tip.style.color = '#d00';
    tip.style.fontWeight = 'bold';
    tip.textContent = '⚠️ 請務必按下「我已抄寫」，以完成 RPS 更新。若要重新啟用封鎖機制，請記得關閉並重啟瀏覽器。';
    appDiv.appendChild(tip);
  }
}



async function saveRPS(rps) {
  await saveToIndexedDB(rps);
 
  const hashed = await sha256WithSalt(rps);

  await saveSetting('mnemonicHash', hashed);
  await renderVerificationUI();
}


async function saveToIndexedDB(rps) {
  const db = await openDB();
  const tx = db.transaction('settings', 'readwrite');
  const store = tx.objectStore('settings');
  await store.put({ key: 'mnemonic', value: rps });
  await tx.done;
}

async function renderVerificationUI() {
  const db = await openDB();
  const tx = db.transaction('settings', 'readonly');
  const store = tx.objectStore('settings');
  const req = store.get('mnemonic');

  req.onsuccess = e => {
    if (!e.target.result || !e.target.result.value) {
      console.warn('⚠️ 無法取得 mnemonic，資料不存在，將自動 reset');
      window.location.href = "chrome://rps-gate/?reset=true";
      return;
    }
    const mnemonic = e.target.result.value;
    const words = mnemonic.split(' ');
    verificationIndices = getRandomIndices(3, 12);

    const appDiv = document.getElementById('app');
    clearElement(appDiv);

    const header = document.createElement('h1');
    header.innerText = '請輸入指定位置的助記詞';
    appDiv.appendChild(header);

    verificationIndices.forEach(i => {
      const row = document.createElement('div');
      const label = document.createElement('label');
      label.innerText = `第 ${i + 1} 個字：`;
      const input = document.createElement('input');
      input.type = 'text';
      input.id = `rps-${i}`;
      input.style.width = '200px';
      input.autocomplete = 'off';
      row.appendChild(label);
      row.appendChild(input);
      appDiv.appendChild(row);
    });

    const verifyBtn = document.createElement('button');
    verifyBtn.innerText = '驗證';
    verifyBtn.addEventListener('click', verify);
    appDiv.appendChild(verifyBtn);

    const statusDiv = document.createElement('div');
    statusDiv.id = 'status';
    statusDiv.className = 'status';
    appDiv.appendChild(statusDiv);

    const logBtn = document.createElement('button');
    logBtn.id = 'showLogBtn';
    logBtn.innerText = '顯示登入紀錄';
    logBtn.addEventListener('click', toggleLogs);
    appDiv.appendChild(logBtn);

    const logArea = document.createElement('pre');
    logArea.id = 'logArea';
    logArea.style.display = 'none';
    appDiv.appendChild(logArea);
  };
}

function getRandomIndices(count, max) {
  const indices = new Set();
  while (indices.size < count) {
    indices.add(Math.floor(Math.random() * max));
  }
  return [...indices].sort((a, b) => a - b);
}

async function verify() {
  const db = await openDB();
  const tx = db.transaction('settings', 'readonly');
  const store = tx.objectStore('settings');
  const request = store.get('mnemonic');

  request.onsuccess = async event => {
    const mnemonic = event.target.result.value;
    const words = mnemonic.split(' ');

    const success = verificationIndices.every(i => {
      const input = document.getElementById(`rps-${i}`);
      const expected = words[i].slice(0, 3).toLowerCase();
      const userInput = input.value.trim().toLowerCase().slice(0, 3);
      return userInput === expected;

    });

    const statusDiv = document.getElementById('status');
    const inputs = verificationIndices.map(i => document.getElementById(`rps-${i}`).value.trim());

    if (success) {
      statusDiv.innerText = '驗證成功';
      await addLogToBothDBs(true, []);
      if (window.chrome && window.chrome.send) {
        chrome.send('setRPSVerified');
        chrome.send('unlockBrowser');
      }
       window.location.replace('chrome://quori/');
    } else {
      statusDiv.innerText = '驗證失敗';
      await addLogToBothDBs(false, inputs); // 失敗記錄輸入值
    }
  };
}

async function addLogToBothDBs(success, wordsArray) {
  const time = Date.now();
  const logEntry = { time, success, words: wordsArray };

  // 寫入 RPSdb.logs
  const rpsDB = await openDB();
  const rpsTx = rpsDB.transaction('logs', 'readwrite');
  const rpsStore = rpsTx.objectStore('logs');
  await rpsStore.add(logEntry);
  await rpsTx.done;
}

async function displayLogs() {
  const db = await openDB();

  // 🔪 清除 30 天前的紀錄
  const txClean = db.transaction('logs', 'readwrite');
  const storeClean = txClean.objectStore('logs');
  const now = Date.now();
  const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;

  const request = storeClean.openCursor();
  request.onsuccess = event => {
    const cursor = event.target.result;
    if (cursor) {
      const log = cursor.value;
      if (log.time < thirtyDaysAgo) {
        cursor.delete(); // 直接刪除這筆
      }
      cursor.continue(); // 移動到下一筆
    }
  };
  await txClean.done;

  // 📋 讀取與顯示最新 10 筆紀錄
  const tx = db.transaction('logs', 'readonly');
  const store = tx.objectStore('logs');
  const req = store.getAll();

  req.onsuccess = e => {
    const logs = e.target.result;
    const logArea = document.getElementById('logArea');

    const logText = logs
      .sort((a, b) => b.time - a.time)
      .slice(0, 10)
      .map(log => {
        const timeStr = log.time ? new Date(log.time).toLocaleString() : '⛔ 無時間';
        const success = log.success;

        if (typeof success === 'boolean') {
          if (success) {
            return `✅ 成功於 ${timeStr}`;
          } else {
            const inputWords = Array.isArray(log.words) ? log.words.join(', ') : '未提供';
            return `❌ 失敗於 ${timeStr}，輸入: ${inputWords}`;
          }
        } else {
          return `❓ 異常紀錄於 ${timeStr}`;
        }
      })
      .join('\n');

    logArea.textContent = logText || '（尚無紀錄）';
  };
}



function toggleLogs() {
  showLogs = !showLogs;
  const logArea = document.getElementById('logArea');
  if (showLogs) {
    logArea.style.display = 'block';
    displayLogs();
  } else {
    logArea.style.display = 'none';
  }
}

function clearElement(el) {
  if (!el) {
    console.warn("⚠️ clearElement 傳入的是 null，可能該 DOM 元素不存在");
    return;
  }
  while (el.firstChild) {
    el.removeChild(el.firstChild);
  }
}


// ⭐⭐ 最後加上右鍵封鎖＋F12封鎖 ⭐⭐
document.addEventListener('contextmenu', event => event.preventDefault());
document.addEventListener('keydown', event => {
  if (event.key === "F12" ||
      (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === "i")) {
    event.preventDefault();
  }
});

document.addEventListener('DOMContentLoaded', setupPage);

